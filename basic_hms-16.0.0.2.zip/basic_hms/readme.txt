
=> 16.0.0.1 : migrated the basic_hms module v15 to v16.

16.0.0.2 ==> Fixed issue of when create new patient from appointments at that time show error and also fixed lab test type one2mnay field issue.