This module has the following limitations:

* No support for planning/agenda of the rented products (i.e. you can't rely on this module to check your capacity to rent a product for the selected dates when you create a quote)
* The unit of measure of the rental services must be *Day* (the rental per hour / per week / per month is not supported for the moment)
