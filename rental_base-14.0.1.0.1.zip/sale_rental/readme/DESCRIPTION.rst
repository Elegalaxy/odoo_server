With this module, you can rent products with Odoo. This module supports:

* regular rentals.
* rental extensions.
* sale of rented products.
