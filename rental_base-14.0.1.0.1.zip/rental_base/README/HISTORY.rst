
Changelog
---------

- 8d191ff7 2022-04-10 15:41:16 +0200 wagner@elegosoft.com  add missing/lost documentation (issue #4516)
- 39ff8efc 2022-03-14 15:15:31 +0100 cpatel@elegosoft.com  [IMP] rental_tour correction, (issue#4516)
- ac980b89 2022-02-28 17:36:28 +0100 cpatel@elegosoft.com  [FIX][IMP] correct code, (issue#4516)
- 4509f78a 2022-02-23 20:48:33 +0100 wagner@elegosoft.com  (origin/feature_4516_add_files_ported_from_v12_v14, feature_4516_add_files_ported_from_v12_v14) add files ported to v14 by cpatel and khanhbui (issue #4516)
